# The patchs is used to test crucio on openstack

- clone these patchs and use following command to run DATS:
	./dats.py -f dats-patchs/openstack-dats.cfg -d dats-patchs/openstack-patchs -r dats-report-tests-openstack_0001
